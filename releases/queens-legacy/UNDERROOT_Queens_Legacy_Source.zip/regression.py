from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(e.stack));page.goto('http://127.0.0.1:8010');page.click('#begin');page.wait_for_timeout(500)
 print('loading cleared',page.locator('#wfLoading').count()==0)
 print('deposits',page.evaluate('nodes.length'));assert page.evaluate('nodes.length===15')
 page.evaluate("QL.breed('worker');qlPanel.close();paused=true;window.testClock=QL.state.clock");page.wait_for_timeout(600);assert page.evaluate('testClock===QL.state.clock');page.evaluate('paused=false;WFPlatform.adLock=true');page.wait_for_timeout(400);assert page.evaluate('testClock===QL.state.clock');page.evaluate('WFPlatform.adLock=false');print('pause/ad lock freezes incubation')
 page.evaluate('save()');page.reload();page.click('#begin');page.wait_for_timeout(300)
 print('gather',page.evaluate("()=>{const n=nodes.filter(n=>n.kind==='leaf').sort((a,b)=>dist(a,explorer)-dist(b,explorer))[0];explorerDestination({x:n.x+30,y:n.y+20});return n.id}"));page.wait_for_timeout(6000)
 if page.locator('#gatherNow').is_visible():
  page.click('#gatherNow');page.wait_for_timeout(3500);assert page.evaluate('explorerCarry>0');page.click('#scoutHome');page.wait_for_timeout(7000);print('gather/delivery',page.evaluate('({carry:explorerCarry,deliveries:sessionStats.playerDeliveries})'));assert page.evaluate('sessionStats.playerDeliveries>0')
 else: print('gather movement did not arrive within test window; not claimed')
 for w,h in [(360,800),(390,844),(768,1024),(1366,768)]:
  page.set_viewport_size({'width':w,'height':h});page.click('#qlOpen');assert page.evaluate('qlPanel.scrollWidth<=qlPanel.clientWidth');page.click('#qlClose')
 print('four nursery layouts passed')
 # Entire colony temporarily empty: reload may not invent a fallback worker.
 page.evaluate('ants=[explorer];S.workers=1;S.soldiers=0;QL.state.eggs=[];QL.die(explorer);save()');page.reload();page.click('#begin');page.wait_for_timeout(200);assert page.evaluate('ants.length===0&&!!QL.state.rebirth');page.wait_for_timeout(6000);assert page.evaluate('ants.length===1&&explorerMode');print('last-ant recovery passed')
 pg=b.new_page();pg.on('pageerror',lambda e:errors.append(e.stack));pg.goto('http://127.0.0.1:8011');pg.wait_for_function('!document.querySelector("#begin").disabled');pg.click('#begin');pg.wait_for_timeout(500);print('SDK',pg.evaluate('({version:bridge.version,platform:bridge.platform.id,started:gameStarted,ads:WFPlatform.adsAvailable()})'));assert pg.evaluate('gameStarted&&bridge.version==="2.4.0"');print('errors',errors[:4]);assert not errors;b.close()

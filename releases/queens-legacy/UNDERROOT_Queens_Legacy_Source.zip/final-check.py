from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();err=[];page.on('pageerror',lambda e:err.append(str(e)));page.goto('http://127.0.0.1:8010');page.click('#begin');page.wait_for_timeout(300)
 # Old schema fixture: same original serialization fields, no new lifecycle extension.
 page.evaluate('''()=>{let d=wfSerialize();delete d.queensLegacy;d.chambers=d.chambers.filter(c=>!['nursery','seeds','creatures'].includes(c.kind));localStorage.setItem(KEY,JSON.stringify(d))}''');page.reload();page.click('#begin');page.wait_for_timeout(300);assert page.evaluate('ants.length===4&&QL.capacity()===2');print('legacy migration retains four ants')
 # Exercise all chamber types, including newly built original rooms.
 print('chamber types',page.evaluate('''()=>{S.soil=100000;S.leaves=100000;S.food=100000;S.seeds=100000;buildChamber('barracks');buildChamber('fungus');for(const c of chambers.filter(c=>['barracks','fungus'].includes(c.kind))){while(c.level<12){if(!QL.upgrade(c))throw Error('upgrade');QL.state.clock=c.upgrade.completeAt;QL.tick(0)}}return chambers.map(c=>[c.kind,c.level])}'''))
 page.evaluate('''()=>{switchScene('surface');while(ants.length<50){let a=makeAnt('worker');ensureAntId(a);ants.push(a)}window.qFrames=[];let last=performance.now();function f(t){qFrames.push(t-last);last=t;if(qFrames.length<180)requestAnimationFrame(f)}requestAnimationFrame(f)}''');page.wait_for_timeout(4500);print('50-ant stress',page.evaluate('''()=>{let a=qFrames.slice(5).sort((a,b)=>a-b);return {samples:a.length,p50:a[Math.floor(a.length*.5)],p95:a[Math.floor(a.length*.95)]}}'''))
 assert not err,err;print('errors',err);b.close()

from pathlib import Path
import zipfile,shutil,hashlib
r=Path('/workspace/queens-legacy');out=r/'dist';out.mkdir(exist_ok=True)
for folder,label in [('game','Standalone'),('playgama','Playgama')]:
 for f in (r/'docs').glob('*.md'):shutil.copy(f,r/folder/f.name)
 path=out/f'UNDERROOT_Queens_Legacy_{label}.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f in (r/folder).rglob('*'):
   if f.is_file():z.write(f,f.relative_to(r/folder))
 with zipfile.ZipFile(path) as z:assert 'index.html' in z.namelist();assert z.testzip() is None
 assert path.stat().st_size<300_000_000
 print(path.name,path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest())
path=out/'UNDERROOT_Queens_Legacy_Source.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['game','playgama','docs','original']:
  for f in (r/folder).rglob('*'):
   if f.is_file():z.write(f,f.relative_to(r))
 for name in ['test.py','extended.py','regression.py','final-check.py','package.py']:z.write(r/name,name)
with zipfile.ZipFile(path) as z:assert z.testzip() is None
print(path.name,path.stat().st_size)

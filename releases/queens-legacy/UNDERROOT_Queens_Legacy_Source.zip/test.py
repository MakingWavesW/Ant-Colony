from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':768});errs=[];page.on('pageerror',lambda e:errs.append(e.stack));page.goto('http://127.0.0.1:8010');page.click('#begin');page.wait_for_timeout(500)
 print('initial',page.evaluate('({cap:QL.capacity(),ants:ants.length,rooms:chambers.map(c=>[c.kind,c.level])})'))
 page.click('#qlOpen');page.click('#qlWorker');page.click('#qlSoldier');print('eggs',page.evaluate('QL.state.eggs.map(e=>({type:e.type,cost:e.cost}))'))
 assert page.evaluate('QL.state.eggs.length===2&&QL.capacity()===2');assert page.evaluate("QL.breed('worker')===false")
 page.evaluate('save()');page.reload();page.click('#begin');page.wait_for_timeout(300);print('reload eggs',page.evaluate('QL.state.eggs.length'));assert page.evaluate('QL.state.eggs.length===2')
 print('death',page.evaluate('''() => {S.food=75;QL.die(explorer);return {food:S.food,r:QL.state.rebirth,eggs:QL.state.eggs.map(e=>[e.type,e.status])}}'''))
 assert page.evaluate('S.food===67&&QL.state.rebirth.cost===8&&QL.state.eggs.length===3')
 page.evaluate('save()');page.reload();page.click('#begin');page.wait_for_timeout(300);assert page.evaluate('QL.state.rebirth.cost===8&&QL.state.eggs.length===3');before=page.evaluate('S.food')
 page.screenshot(path='/workspace/queens-legacy/rebirth.png');page.wait_for_timeout(19000)
 print('hatch',page.evaluate('({rebirth:QL.state.rebirth,ants:ants.length,player:ants.filter(a=>a.player).length,eggs:QL.state.eggs.length,history:QL.state.history})'))
 assert page.evaluate('!QL.state.rebirth&&explorerMode&&ants.filter(a=>a.player).length===1&&QL.state.eggs.length===0')
 print('zero recovery',page.evaluate('''()=>{S.food=0;QL.die(explorer);return QL.state.rebirth.cost}'''));assert page.evaluate('S.food===0');page.wait_for_timeout(6000);assert page.evaluate('!QL.state.rebirth&&explorerMode')
 print('upgrade',page.evaluate('''()=>{S.leaves=999;S.soil=999;let c=QL.room('nursery');let first=QL.upgrade(c),balance=S.leaves,second=QL.upgrade(c);save();return {first,second,noDouble:balance===S.leaves}}'''))
 page.reload();page.click('#begin');page.wait_for_timeout(19000);assert page.evaluate("QL.room('nursery').level===2&&QL.capacity()===4");print('upgrade survived reload')
 page.click('#qlOpen');page.screenshot(path='/workspace/queens-legacy/nursery.png');page.set_viewport_size({'width':390,'height':844});page.screenshot(path='/workspace/queens-legacy/mobile.png');page.click('#qlClose');assert not page.locator('#qlPanel').is_visible();print('errors',errs[:4]);assert not errs;b.close()

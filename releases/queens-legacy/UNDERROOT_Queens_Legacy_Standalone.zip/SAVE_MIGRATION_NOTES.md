# Save compatibility

The existing schema-4 save retains all original fields and adds `queensLegacy.version = 1`: serial, logical clock, active/queued eggs, a single charged rebirth transaction and recent hatch receipts. Each chamber retains its kind/position and gains an ID, maxLevel and optional construction transaction. Ant saves additionally retain birth egg ID and maximum HP.

Older colonies keep their living ants, resources, map, quests and upgrades. Missing Nursery, Seed Vault and Ranger rooms are added at level one; existing levels above the new maximum are clamped to 12. No legacy ant is retroactively charged an egg cost. The existing population-building mission still completes on actual hatch, not purchase. A saved empty colony with pending rebirth does not receive the original loader's fallback free worker.

Egg completion and births are persisted in the same existing save operation. Queued replacement transactions already contain the charged food amount, so reload never reapplies the cost. Timer remaining durations survive reload; no offline-time rewards. Local write failures remain subject to the original save backend's availability, and remote writes use its serialized persistence queue.

Standalone uses existing local browser keys at the same origin. Playgama uses the official Bridge storage facade and `underroot_bundle_v1`. The actual deployed live game's cloud schema was not available: verify its migration in Sandbox before replacing a live release. Source backups do not back up browser/cloud player data.

To revert files, extract the original source ZIP. Back up player storage independently before release. Reset uses the existing game's reset flow; new lifecycle state is inside that same colony save, so no unrelated browser keys are removed.

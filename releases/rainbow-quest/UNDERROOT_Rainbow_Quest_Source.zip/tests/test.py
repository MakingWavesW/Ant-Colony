from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.goto('http://127.0.0.1:8020');page.click('#begin');page.wait_for_timeout(500)
 print(page.evaluate('({quests:JourneyQuests.length,slots:QL.capacity()})'))
 page.evaluate("depositResource('leaf',1,BASE,'player');depositResource('food',1,BASE,'player');rainbowClose();QL.breed('worker')");assert page.evaluate('Journey.index===2');page.wait_for_timeout(9000);assert page.evaluate('Journey.index===3');print('hatch-only quest passed')
 page.evaluate('rainbowClose();save()');page.reload();page.click('#begin');page.wait_for_timeout(300);assert page.evaluate('Journey.index===3&&!!QL.state');print('joint save passed')
 page.click('#wfBonus');page.screenshot(path='/workspace/rainbow/bonus-desktop.png')
 for w,h in [(360,800),(390,844),(768,1024),(844,390),(1280,720),(1920,1080)]:
  page.set_viewport_size({'width':w,'height':h});assert page.evaluate('document.querySelector(".wfBonusPanel").getBoundingClientRect().width<=innerWidth');page.screenshot(path=f'/workspace/rainbow/bonus-{w}.png')
 page.evaluate('rainbowClose();QL.open()');page.evaluate("document.querySelector('#journeyJournal').click()");assert page.evaluate('document.querySelectorAll("dialog[open]").length===1');print('modal ownership passed')
 print('errors',errs);assert not errs;b.close()

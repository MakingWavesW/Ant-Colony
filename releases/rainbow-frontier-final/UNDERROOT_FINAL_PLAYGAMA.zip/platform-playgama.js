/* Official @playgama/bridge 2.4.0. No simulated ad completion in this adapter. */
WFPlatform.name='playgama';WFPlatform.local=false;
let pgReady=false,pgAbandoned=false,pgReadySent=false,pgReadyRequested=false,pgAdActive=false,pgGameplay=false,pgBanner=false,pgLastBreak=performance.now();
function pgMessage(message){try{Promise.resolve(bridge.platform.sendMessage(message)).catch(()=>{})}catch{}}
WFPlatform.gameReady=()=>{pgReadyRequested=true;pgMaybeReady()};
function pgMaybeReady(){const loading=document.getElementById('wfLoading');if(pgReady&&pgReadyRequested&&!pgReadySent&&document.readyState!=='loading'&&(!loading||loading.classList.contains('wfLoaded'))){pgReadySent=true;pgMessage(bridge.PLATFORM_MESSAGE.GAME_READY)}}
WFPlatform.adsAvailable=()=>pgReady&&!pgAbandoned&&bridge.platform.id==='playgama'&&bridge.advertisement.isRewardedSupported&&!pgAdActive;
WFPlatform.persist=async()=>{await WFPlatform.ready;if(!pgReady||pgAbandoned)throw Error('Platform storage unavailable');await bridge.storage.set('underroot_bundle_v1',JSON.stringify(wfStorageObject()))};
WFPlatform.requestAd=(offer,onVerified)=>new Promise(resolve=>{
 if(!WFPlatform.adsAvailable())return resolve(false);pgAdActive=true;let rewarded=false,finished=false,verification=Promise.resolve();
 const finish=async()=>{if(finished)return;finished=true;clearTimeout(timer);bridge.advertisement.off(bridge.EVENT_NAME.REWARDED_STATE_CHANGED,onState);try{await verification}catch{}pgAdActive=false;WFPlatform.adShowing=false;WFPlatform.notifyState();resolve(rewarded)};
 const onState=state=>{if(finished)return;if(state===bridge.REWARDED_STATE.OPENED||state===bridge.REWARDED_STATE.LOADING){WFPlatform.adShowing=true;WFPlatform.notifyState()}if(state===bridge.REWARDED_STATE.REWARDED&&!rewarded){rewarded=true;verification=Promise.resolve().then(()=>onVerified?.());verification.catch(()=>{})}if(state===bridge.REWARDED_STATE.CLOSED||state===bridge.REWARDED_STATE.FAILED)finish()};
 // On timeout, don't let a late callback authorize a different transaction.
 const timer=setTimeout(()=>{WFPlatform.adsAvailable=()=>false;finish()},180000);
 bridge.advertisement.on(bridge.EVENT_NAME.REWARDED_STATE_CHANGED,onState);try{bridge.advertisement.showRewarded('underroot_'+offer)}catch{finish()}
});
WFPlatform.ready=(async()=>{try{
 await bridge.initialize({configFilePath:'playgama-bridge-config.json'});
 const raw=await bridge.storage.get('underroot_bundle_v1',false);if(pgAbandoned)throw Error('Connection expired');
 if(raw){const data=typeof raw==='string'?JSON.parse(raw):raw;if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Invalid saved bundle');wfSeedStorage(data)}
 pgReady=true;const sync=()=>{WFPlatform.paused=!!bridge.platform.isPaused;WFPlatform.audioAllowed=bridge.platform.isAudioEnabled!==false;WFPlatform.notifyState()};bridge.platform.on(bridge.EVENT_NAME.PAUSE_STATE_CHANGED,sync);bridge.platform.on(bridge.EVENT_NAME.AUDIO_STATE_CHANGED,sync);sync();pgMaybeReady();
 }catch(e){WFPlatform.initError='Platform connection unavailable. Retry, or play this session without cloud saving.';throw e}})();WFPlatform.ready.catch(()=>{});
addEventListener('DOMContentLoaded',()=>{
 const begin=document.getElementById('begin');begin.disabled=true;begin.textContent='CONNECTING TO COLONY…';let settled=false;
 const fail=()=>{if(settled)return;settled=true;pgAbandoned=true;pgReady=false;begin.disabled=false;begin.textContent='PLAY THIS SESSION';WFPlatform.initError='Platform connection unavailable. This session cannot sync cloud saves.';const note=document.createElement('p');note.textContent=WFPlatform.initError;begin.after(note);const retry=document.createElement('button');retry.textContent='RETRY CONNECTION';retry.onclick=()=>location.reload();note.after(retry)};
 const timeout=setTimeout(fail,12000);WFPlatform.ready.then(()=>{clearTimeout(timeout);if(settled)return;settled=true;begin.disabled=false;begin.textContent=WFStorage.getItem('underroot_colony_v1')?'CONTINUE COLONY':'PLAY'}).catch(fail);
 setInterval(()=>{pgMaybeReady();if(!pgReady)return;const active=gameStarted&&!paused&&!WFPlatform.paused&&!WFPlatform.adShowing&&!WFPlatform.adLock&&!document.hidden&&$('overlay').style.display==='none';if(active!==pgGameplay){pgGameplay=active;pgMessage(active?bridge.PLATFORM_MESSAGE.GAMEPLAY_STARTED:bridge.PLATFORM_MESSAGE.GAMEPLAY_STOPPED)}
 const rect=$('intro').getBoundingClientRect(),ad=bridge.advertisement;const desired=bridge.platform.id==='playgama'&&ad.isAdvancedBannersSupported&&innerWidth>=1400&&innerHeight>=650&&$('overlay').style.display!=='none'&&rect.right<innerWidth*.82&&!document.querySelector('dialog[open]')&&!document.hidden&&!WFPlatform.adLock&&!WFPlatform.adShowing;
 if(desired!==pgBanner){pgBanner=desired;try{if(desired)ad.showAdvancedBanners('main_menu');else ad.hideAdvancedBanners()}catch{pgBanner=false}}
 },250);
 // A genuine return-to-menu break, at most once per three minutes; never on startup/death.
 $('guiReturn').addEventListener('click',()=>{if(!pgReady||bridge.platform.id!=='playgama'||!bridge.advertisement.isInterstitialSupported||performance.now()-pgLastBreak<180000||WFPlatform.adLock||pgAdActive||QL.state.rebirth||enemies.some(e=>!e.dead&&['chase','windup','attack'].includes(e.state)))return;pgLastBreak=performance.now();pgAdActive=true;WFPlatform.adShowing=true;WFPlatform.notifyState();let terminal=false;const finish=()=>{if(terminal)return;terminal=true;clearTimeout(timer);bridge.advertisement.off(bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED,listener);pgAdActive=false;WFPlatform.adShowing=false;WFPlatform.notifyState()};const listener=state=>{if(state===bridge.INTERSTITIAL_STATE.CLOSED||state===bridge.INTERSTITIAL_STATE.FAILED)finish()};const timer=setTimeout(finish,180000);bridge.advertisement.on(bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED,listener);try{bridge.advertisement.showInterstitial('return_to_menu')}catch{finish()}});
});

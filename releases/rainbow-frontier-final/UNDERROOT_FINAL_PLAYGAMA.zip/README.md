# UNDERROOT: Ant Colony Chronicles — Rainbow Frontier

Complete Part 3 candidate built on Checkpoint B. Start with RELEASE_AND_UPLOAD_GUIDE.md and the current test report. Run index.html through a local/static HTTP server. Gameplay assets, fonts and music are bundled; only the Playgama target uses the real platform SDK. No live publication was performed.

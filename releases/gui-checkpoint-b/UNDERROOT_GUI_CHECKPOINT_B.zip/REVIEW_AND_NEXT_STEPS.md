# UNDERROOT — GUI, Quest Offers, Loading Screen: Implementation Review

## Source audit
- Original standalone `index(2).html` is one approximately 288 KB HTML file with nine stacked CSS blocks. Several later CSS rules override earlier layout rules, producing the crowded HUD and panels on smaller devices.
- The existing `WFRewards` service already supports exactly-once resource rewards, save attempts, and official-ad-confirmed grants. **Standalone `WFPlatform.adsAvailable()` returns false and `requestAd()` returns false.** This file cannot display monetized Playgama ads without its Playgama Bridge adapter.
- The original file referenced `adventure.js` at the end but it was not provided; removed the dead reference from this standalone package. Any functionality formerly located only in that missing script is NOT present.
- Original mission completion increments `S.mission` inside `update` and awards resources directly; new optional ad prompt observes these real completion events.

## Changes in this package
1. Included optimized original loading artwork as separate WebP, with an interactive overlay showing real readiness milestones (browser script readiness, image decoded, fonts ready). No artificial delay. Baked loading bar in image is visually covered by a new live HTML progress bar.
2. Added dismissible quest-completion reward card, with `Watch Ad` only enabled when the official platform indicates ads available; safe disabled state in this standalone edition. Never grants unverified rewards.
3. Added × buttons to quest/command panels, context resource panel, optional tutorial, army panel, and explorer toolbar; existing dialogs already had close controls. Added Escape handling.
4. Hid the permanently exposed five-tab menu behind `☰ Menu` for more gameplay space.
5. Reduced top HUD clutter with horizontal resource scrolling. Improved stacked panel layout for mobile.

## Platform notes
- **Not a Playgama publishing build:** the provided file has `WFPlatform.name='standalone'`. Publishing with rewarded ads requires inserting and testing the official Playgama Bridge SDK/adapter in the actual Playgama build.
- Real ad display cannot be tested outside a Playgama-provided ad environment.
- Studio intro video has not been bundled in this release, pending the user-selected final asset. Recommended short, skippable 2–3 second clip while loading, no forced startup delay.
- Existing sound effects appear primarily procedural. Review music licensing, platform mute/pause rules, and bundled compressed audio before publishing.

## Further improvements recommended
- Refactor nine stacked stylesheets into scoped component CSS and explicit UI-state machine, instead of relying on many conflicting position overrides.
- Rework 5 legacy missions to teach gathering, ant recruitment, colony expansion, and low-risk combat in a satisfying 8–10 minute progression; persist the quest state.
- Use a playable tutorial and progressive button disclosure; minimize overlays and optimize first 30 seconds.
- Implement real Playgama SDK with lifecycle/audio/save, safe ad placement only at natural quest breaks, and real Playgama moderation QA.
- Replace remaining placeholder/emoji-heavy creature art and add dedicated high-quality audio files where appropriately licensed.
- Profile CPU (ants and creature AI), canvas rendering, frame time, and mobile touch interaction on actual devices before another world expansion.

## Testing notes
- All seven inline JavaScript blocks passed `node --check`, and the loading artwork file was generated successfully. Browser rendering could not be smoke-tested here: the local Chromium environment blocked both `file://` and localhost navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Live platform ad callbacks, touch interaction, full cross-device performance, and Playgama moderation remain unverified.

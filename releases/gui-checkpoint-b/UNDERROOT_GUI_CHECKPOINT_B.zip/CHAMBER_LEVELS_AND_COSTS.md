# Chamber levels and costs

Shared upgrade costs use existing leaves, soil and seeds. Costs below buy the next level; all rooms use the same curve. Confirm before charging. One active transaction per room. No resin or water is required.

| Upgrade | Leaves | Soil | Seeds | Active seconds | Nursery slots after |
|---|---:|---:|---:|---:|---:|
| 1 → 2 | 14 | 18 | 0 | 18 | 4 |
| 2 → 3 | 36 | 48 | 0 | 26 | 6 |
| 3 → 4 | 62 | 84 | 8 | 36 | 8 |
| 4 → 5 | 91 | 125 | 23 | 46 | 10 |
| 5 → 6 | 123 | 171 | 42 | 57 | 12 |
| 6 → 7 | 157 | 221 | 64 | 68 | 14 |
| 7 → 8 | 194 | 274 | 89 | 80 | 16 |
| 8 → 9 | 232 | 331 | 118 | 93 | 18 |
| 9 → 10 | 272 | 390 | 148 | 106 | 20 |
| 10 → 11 | 313 | 452 | 181 | 119 | 22 |
| 11 → 12 | 356 | 517 | 216 | 132 | 24 |

Level 12 is terminal. Nursery starts with two slots.

Benefits: Queen −3% incubation duration and +4% newborn soldier HP per level above one; Nursery 2×level simultaneous eggs; Seed Vault min(9999, 2000+1000×level) storage; Ranger +level HP/second at the safe anthill; Granary +100×level food capacity; Barracks +4×level soldier capacity; Fungus +6×level food per existing production cycle. Existing economy rules still apply to population caps and fungus input costs.

Chamber effects are implemented, but this curve has not undergone a long-term human balance study.

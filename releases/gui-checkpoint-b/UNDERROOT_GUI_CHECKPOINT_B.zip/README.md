# UNDERROOT: The Queen’s Legacy

Unzip the standalone package, run `python3 -m http.server 8000` in that folder, and open the local server in your browser. Enter the colony and press NURSERY. Breed workers/soldiers, inspect active eggs, and confirm chamber upgrades. Original movement, gathering, Army, map and nest controls remain available.

The Playgama ZIP is a separate Sandbox candidate with official Bridge 2.4.0 bundled locally. Upload it to a draft, then test platform saving and real rewarded-ad callbacks before changing your live release. No publishing or account changes were performed. index.html is at the root of both ZIPs.

The source ZIP includes both complete target folders, documentation, browser test scripts and the original supplied ZIP. No build tool is required. Third-party Bridge licensing is included beside the unmodified SDK; its official source is https://github.com/playgama/bridge (package @playgama/bridge 2.4.0).

The supplied loading artwork and the three previously supplied MP3 tracks are bundled. Music follows user gesture, mute, pause, background and ad state, with exploration/battle transitions. Commercial audio/art rights have not been independently verified. Do not assume Playgama publishing approval from local test results.

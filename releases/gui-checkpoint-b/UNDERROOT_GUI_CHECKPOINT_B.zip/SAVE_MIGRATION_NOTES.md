# Saves

Existing schema-4 payload retained with independent queensLegacy and journey objects. Reference Journey version 1 IDs, counts, completed chapters and music volume load unchanged; optional offers is additive. Queen eggs, clock, rebirth transaction and upgrade states retain original serialization. No duplicate ant creation controller was added.

Absent Journey data starts chapter 1 without removing colony progress. Queen migration continues to grandfather existing ants. Completed quests do not dispatch offers on load. Reward transactions remain in frontier.rewards; 180-second harvest boost remains in frontier.boost. Local origin must match for existing browser saves. Published Playgama cloud-save compatibility requires testing against that deployment's actual schema.

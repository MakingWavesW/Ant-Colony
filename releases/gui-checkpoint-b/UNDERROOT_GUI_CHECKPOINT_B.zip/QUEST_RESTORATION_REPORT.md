# Quest restoration

All 12 original IDs, goals and leaf rewards retained. Initialization order: original game → Queen’s Legacy → Adventure → one music controller → Rainbow UI. Hatching emits the worker event only when the worker exists; QL.tick emits the Queen event only when its level increases. Purchases do not advance these chapters. Journey serialization calls Queen serialization rather than replacing it.

Normal reward is granted once against completed IDs and saved before optional offer dispatch. Offers never gate quest progression. Optional celebration waits for a natural break, records availability/decline/request/result, and does not replay completed quests on reload. Rapid completions may coalesce into the latest celebration; normal rewards remain intact. The journal includes all chapters and X/Escape closure.

Integration tests completed all chapters, but kill/discovery tests used controlled state fixtures rather than natural combat/exploration. Worker-priority delivery retains reference behavior: a worker delivery while a priority order is active qualifies; per-cargo origin matching remains an improvement opportunity.

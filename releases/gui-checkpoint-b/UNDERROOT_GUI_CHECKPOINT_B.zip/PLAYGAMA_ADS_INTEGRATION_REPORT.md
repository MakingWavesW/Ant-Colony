# Platform ads

Official unmodified @playgama/bridge 2.4.0 bundled, with license. API contracts inspected from official GitHub source and published declarations. Official wiki access returned 403 earlier in this session; live/current portal requirements still need review before submission.

Reward adapter checks isRewardedSupported on Playgama, uses showRewarded and REWARDED_STATE_CHANGED, and resolves success only after rewarded then closed. Duplicate callbacks settle once. Existing WFRewards persists pending, verified, credited and save-retry states. No reward on failure, cancellation or timeout. Storage-limited offers are disabled when the whole advertised reward cannot fit. Six original amounts unchanged. Seed cap respects Nursery-era Seed Vault.

Local provider mocks and isolated adapter callback tests passed; real ad inventory/callbacks and remote-save failure recovery are unverified. Advanced banners are separately configured. Interstitial lifecycle events pause/audio-gate; no new interstitial request placement was introduced because the base had none, avoiding untested interruption. No startup ad duplication. No YouTube SDK initialization.

Standalone never supplies a rewarded provider. Mock tests live only in source test scripts. Technical diagnostics remain in test output, not player UI.

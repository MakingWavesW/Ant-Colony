# GUI checks

Chromium screenshots: 360×800, 390×844, 768×1024, 844×390, 1280×720 and 1920×1080. Bonus panel stays within viewport width and scrolls vertically. Portrait screenshot inspected. Close and continue buttons retained, 44px touch minimum, reduced-motion effects, native dialog Escape closure. Major native dialogs close one another and hide Bonus Center; legacy mission offer popup suppressed. Real Advanced Banner overlaps are not verified.

After screenshots are included in source/screenshots. No newly captured before screenshots are supplied. Full gameplay overlays and physical touch input need further manual audit.

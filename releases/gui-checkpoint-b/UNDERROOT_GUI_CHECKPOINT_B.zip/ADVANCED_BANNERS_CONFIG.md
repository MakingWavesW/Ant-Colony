# Optional Advanced Banner

Only one desktop Adventure Journal placement is configured: width 18%, height 40%, left 79%, top 30%. It is requested only on Playgama when official isAdvancedBannersSupported is true, viewport is at least 1280px wide, the Journal is open, and no fullscreen ad is active. It hides on Journal close, active exploration, narrower orientation, hidden page or fullscreen ad. Phones/tablets have no banner placement; no unsupported fallback or fake banner is drawn.

Configuration is in playgama-bridge-config.json under advertisement.advancedBanners.journal.default. Geometry uses percentages. Nursery placement is intentionally omitted to protect egg and upgrade controls. Real rendering, supported-platform behavior and impressions remain unverified in Sandbox; local mock capability is not a banner test. Rainbow Bonus Center is custom game UI, not an Advanced Banner.

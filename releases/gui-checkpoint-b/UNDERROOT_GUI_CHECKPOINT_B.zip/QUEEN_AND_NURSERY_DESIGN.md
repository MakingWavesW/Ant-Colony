# The Queen’s Legacy — build 2026-10-31

This modifies the supplied GUI/Quest/Loading Upgrade, preserving its simulation and loading artwork. The original ZIP is retained separately in original/source.zip, SHA-256 891b535ad0de56f9e3ada92e1f417499633c86b55e9f9ae6cd877e10fde7fedd.

All new worker/soldier orders route through `QL.breed`; their old instant-spawn bodies are removed. The existing founding colony and previously saved ants are grandfathered, not deleted and recreated. Explorer control may use an existing worker; replacement bodies after death always come from an Explorer Egg. Load reconstruction is not a new birth.

Worker egg: 18 food + 5 leaves, 8 seconds base. Soldier: 30 food + 15 leaves, 12 seconds base. Explorer: ceil(stored food × 0.10), snapshotted and charged once, 5 seconds base. Queen levels reduce incubation by 3% per level above one (33% at level 12). New soldiers receive 4% more maximum health per level above one. Existing soldiers are retained unchanged.

Nursery slots equal twice its level, from 2 to 24. Pending eggs reserve population capacity. No automatic breeding, free ordinary eggs, or advertising requirement. Full nurseries reject ordinary orders and queue the replacement Explorer behind currently incubating eggs; the queued Explorer gets the next free slot. No existing egg is deleted. A zero-food Explorer replacement costs zero.

Death removes the fallen body, clears control and cargo, saves the food transaction and replacement egg together, opens the nest and recovery panel, and disables world input until recovery. The optional panel can close with X/Escape without canceling incubation. Hatching creates one initialized body near the safe anthill, restores control and stamina, and persists completion. The colony and its other progress remain intact. Surface hatch positions are within the obstacle-free colony safe zone and use bounded occupancy checks.

Canvas Queen art includes articulated legs/antennae, breathing/laying motion, pulsing eggs, cracking and shell effects. Attendants in this illustration are cosmetic; gathering workers are not reassigned as simulated nursery haulers. World-space eggs are visible in the Nursery. Advanced creature capture/fusion, resin and water systems are not invented. The Ranger Chamber provides real safe-home healing instead.

Timers use a persisted logical epoch and completion timestamps. They advance only during active unpaused simulation, stop for hidden pages/platform pauses/ads, and retain remaining time through reload. Offline time does not finish construction. Clock changes cannot accelerate these gameplay timers. Load normalizes durations and clamps upgrade levels.

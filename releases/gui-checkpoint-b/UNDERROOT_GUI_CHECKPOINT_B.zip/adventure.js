/* Great Colony Rebuild: additive, versioned progression over the preserved simulation. */
'use strict';
const Journey={version:1,index:0,counts:{},settings:{volume:.38},completed:[],offers:{}};
const JourneyQuests=[
 ['first-leaf','A small leaf. A big beginning.','Deliver leaves to the anthill.','leaf',1,12,'leaf'],
 ['queen-berries','Breakfast for the queen','Gather berries and bring them home.','food',1,15,'food'],
 ['helping-mandibles','Many mandibles make light work','Hatch a worker in Colony.','worker',1,20],
 ['pheromone','Leave a trail worth following','Order workers to a deposit; let them deliver.','orderedDelivery',1,20,'leaf'],
 ['growing-home','Room to grow','Build a chamber in the underground nest.','build',1,25],
 ['atlas','Beyond the familiar path','Open your world map.','map',1,15],
 ['escort','Never walk alone','Recruit a soldier escort from Army.','recruit',1,20],
 ['threat','Stand your ground','Defeat a creature with your soldiers.','kill',1,25],
 ['return','A safe return','Bring another load of supplies home.','delivery',1,20],
 ['convoy','The colony provides','Receive three worker deliveries.','workerDelivery',3,25],
 ['wilderness','A world beneath the grass','Discover a landmark.','landmark',1,30],
 ['colony-rises','The colony rises','Upgrade the queen chamber.','queen',1,40]
].map(([id,title,hint,event,goal,reward,target])=>({id,title,hint,event,goal,reward,target}));
function journeyEvent(type,n=1){if(!gameStarted)return;const q=JourneyQuests[Journey.index];if(!q||q.event!==type)return;Journey.counts[q.id]=Math.min(q.goal,(Journey.counts[q.id]||0)+n);if(Journey.counts[q.id]>=q.goal&&!Journey.completed.includes(q.id)){Journey.completed.push(q.id);S.leaves+=q.reward;Journey.index++;burst(BASE.x,BASE.y,'#e9ce75',18);toast('✓ '+q.title+' · +'+q.reward+' leaves');audioFx(880,.16);if(save())document.dispatchEvent(new CustomEvent('journey-completed',{detail:q}))}journeyRender()}
const journeySerialize=wfSerialize;wfSerialize=function(){const d=journeySerialize();d.journey=JSON.parse(JSON.stringify(Journey));return d};
const journeyLoad=load;load=function(){let ok=journeyLoad();try{const d=JSON.parse(WFStorage.getItem(KEY)||'null')?.journey;if(d?.version===1){Journey.offers=d.offers||{};Journey.index=clamp(Math.floor(Number(d.index)||0),0,JourneyQuests.length);Journey.counts=d.counts&&typeof d.counts==='object'?d.counts:{};Journey.completed=Array.isArray(d.completed)?d.completed:[];Journey.settings.volume=clamp(Number(d.settings?.volume)||0,0,1)}}catch{}return ok};
const journeyDeposit=depositResource;depositResource=function(kind,quantity,where,who){const remaining=journeyDeposit(kind,quantity,where,who);if(quantity>remaining){if(who==='player'){journeyEvent(kind);journeyEvent('delivery')}else{journeyEvent('workerDelivery');if(priorityNode)journeyEvent('orderedDelivery')}}return remaining};
const journeyBuild=buildChamber;buildChamber=function(...args){let n=chambers.length;journeyBuild(...args);if(chambers.length>n)journeyEvent('build')};
const journeyRecruit=wildRecruit;wildRecruit=function(){journeyRecruit();if(wildSquad.size)journeyEvent('recruit')};
const journeyMap=toggleWorldMap;toggleWorldMap=function(...args){journeyMap(...args);if(args[0]!==false)journeyEvent('map')};
const journeyCard=document.createElement('section');journeyCard.id='journey';journeyCard.innerHTML='<small id="journeyChapter"></small><strong id="journeyTitle"></strong><p id="journeyHint"></p><div class="journeyTrack"><i id="journeyFill"></i></div><div class="journeyActions"><button id="journeyTrail">SHOW TRAIL</button><button id="journeyJournal" aria-label="Open adventure journal">JOURNAL</button></div>';document.body.append(journeyCard);
const journal=document.createElement('dialog');journal.id='journeyBook';journal.innerHTML='<h2>Your colony’s story</h2><ol></ol><label>Music volume <input id="journeyVolume" type="range" min="0" max="1" step=".01" value=".38"></label><button id="journeyClose">BACK TO THE COLONY</button>';document.body.append(journal);
$('journeyJournal').onclick=()=>{journal.querySelector('ol').replaceChildren(...JourneyQuests.map((q,i)=>{let li=document.createElement('li');li.textContent=(i<Journey.index?'✓ ':i===Journey.index?'→ ':'')+q.title;li.style.opacity=i>Journey.index?'.55':'1';return li}));$('journeyVolume').value=Journey.settings.volume;journal.showModal()};$('journeyClose').onclick=()=>journal.close();$('journeyVolume').oninput=e=>{Journey.settings.volume=+e.target.value;save()};
function journeyTarget(){const q=JourneyQuests[Journey.index];if(explorerCarry)return BASE;return q?.target?nodes.filter(n=>n.kind===q.target&&n.amount>0).sort((a,b)=>dist(a,explorer||BASE)-dist(b,explorer||BASE))[0]:null}
let journeyTrailUntil=0;$('journeyTrail').onclick=()=>{if(!explorerMode)startExplorer();journeyTrailUntil=elapsed+25;const t=journeyTarget();if(t){explorerDestination(t===BASE?{x:BASE.x,y:BASE.y+35}:{x:t.x+35,y:t.y+25});toast(t===BASE?'Follow the trail home':'Your ant is following the trail')}else{toast(JourneyQuests[Journey.index]?.hint||'Your colony is thriving!')}};
function journeyRender(){const q=JourneyQuests[Journey.index];journeyCard.hidden=!gameStarted;$('journeyChapter').textContent=q?'CHAPTER '+(Journey.index+1)+' / 12':'THE WILD FRONTIER';$('journeyTitle').textContent=q?.title||'A colony of your own';$('journeyHint').textContent=q? q.hint+' '+(Journey.counts[q.id]||0)+'/'+q.goal:'Explore, grow and protect your colony.';$('journeyFill').style.width=q?100*(Journey.counts[q.id]||0)/q.goal+'%':'100%'}
let journeyTicks=0,journeyKills=0,journeyLandmarks=0;const journeyUpdate=update;update=function(dt){journeyUpdate(dt);if(WFPlatform.paused||WFPlatform.adLock||document.hidden)return;journeyTicks+=dt;if(journeyTicks>.25){journeyTicks=0;let kills=S.kills||0,landmarks=wfLandmarks.filter(l=>l.found).length;if(kills>journeyKills)journeyEvent('kill',kills-journeyKills);if(landmarks>journeyLandmarks)journeyEvent('landmark',landmarks-journeyLandmarks);journeyKills=kills;journeyLandmarks=landmarks;journeyRender()}};
const journeyDraw=draw;draw=function(){journeyDraw();if(!gameStarted||scene!=='surface'||!explorerMode||!explorer)return;const t=journeyTarget();if(!t||!(Journey.index<2||elapsed<journeyTrailUntil))return;const a=scr(explorer.x,explorer.y),b=scr(t.x,t.y);c.save();c.strokeStyle='#f8e6a8aa';c.lineWidth=2;c.setLineDash([3,10]);c.lineDashOffset=-elapsed*12;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();c.setLineDash([]);c.strokeStyle='#e4ed9c';c.lineWidth=3;c.beginPath();c.ellipse(b.x,b.y,35*view.z,24*view.z,0,0,TAU);c.stroke();c.restore()};
$('begin').addEventListener('click',()=>{journeyKills=S.kills||0;journeyLandmarks=wfLandmarks.filter(l=>l.found).length;journeyRender();if(!enhancedLoaded){const n=nodes.filter(n=>n.kind==='leaf').sort((a,b)=>dist(a,BASE)-dist(b,BASE))[0];if(n){n.x=BASE.x+165;n.y=BASE.y+100;tutorialLeaf=n}}});

journeyRender();
document.addEventListener('ql-hatched',e=>{if(e.detail==='worker')journeyEvent('worker')});
const rainbowTick=QL.tick;QL.tick=function(dt){const before=S.queen;rainbowTick.call(this,dt);if(S.queen>before)journeyEvent('queen')};

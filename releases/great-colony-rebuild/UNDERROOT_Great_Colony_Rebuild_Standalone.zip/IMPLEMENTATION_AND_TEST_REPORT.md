# Implementation and test report

Date: 30 October 2026. Version: 1.2.1. Status: review build, not certified.

## What changed

The uploaded 201,024-byte Phase 3 HTML is retained byte-for-byte in `original/phase3.html`. `src/base.html` now has a three-unit gathering tolerance correction, aligning the harvesting arrival threshold with the explorer movement dead zone. It also opens the in-game reset dialog and resolves the current save function at unload, rather than calling a captured older serializer. The build script modifies a copy: expands MAP to 4,700, replaces the old full-map raster cache with viewport chunks, routes persistence through the target adapter and appends the maintained Wild Frontier modules. Existing management, explorer, room geometry, tutorial, resource panel, gait and carry art are reused.

The surface area grows from 4,410,000 to 22,090,000 square world units (5.01×). Five supply types have exactly three independently renewable depots, 1,000–2,300 initial units each. Generation is seeded, depot IDs increase across saves, depletion callbacks are idempotent, inventory is bounded, and current depot locations are reachable around isolated rock obstacles. A path graph is built only when needed and paths are cached per ant. Priority reservations and a cached food-support group preserve useful worker assignments. Soldiers use distributed patrols, local separation and nearby threat targeting without per-frame global sorting.

Four biomes, four discovery landmarks, a discovery-aware minimap/full map, shrinking resource piles and optional landmark rewards are implemented. Predators have original procedural silhouettes and articulated legs/arms: eight-legged spiders, plated beetles, fire ant groups and mantises. They patrol territories, wind up attacks, recover, respect obstacle attack lines and stop pursuit outside their home territory. The initial nest area is safe. A defeated explorer returns to the colony with cargo retained; worker losses still matter.

Seeds now have independent inventory and a Colony action converts 10 seeds to 10 food. Existing food stock is retained on migration. New saves retain depot coordinates/remaining stock, RNG/ID state, discovery, priorities, ants/cargo, queen/rooms, enemies, timed boosts and reward transactions. Legacy saves get a separate backup entry before the new schema replaces their small depots and shifts ant coordinates into the larger world.

## Dangerous discoveries and escort combat

One apex creature and the original 12 weaker creatures (three of each species) are placed initially; one additional apex spawns every 600 seconds of active play. The species cycle is spider, beetle, mantis and rival ant captain. Both maps expose danger locations immediately, as requested: red triangles identify apex creatures and amber circles identify common creatures, with a distinct silhouette per species. World sprites still require the surface explorer to come within 300 units with clear sight. Camera panning and workers do not discover threats. Hidden creatures remain dormant, so they cannot inflict invisible damage.

RECRUIT/R takes min(available soldiers, 10); it costs nothing and does not hatch ants. Followers form a loose ring, approach nearby discovered threats, and disengage when the explorer retreats. ATTACK sends a focused assault toward a discovered creature within 650 units; RETREAT cancels combat and leads the explorer home. Soldiers fan into individual positions around the body while striking. Extra soldiers patrol slowly within roughly 200 units of the anthill. Dismissed ants walk back without teleporting. Guards recover 3 HP/second near home. Underground escorts guard the entrance. Old teleporting army/rally commands are replaced with return-to-patrol orders.

Apex silhouettes are rendered at twice their previous size. Their wide health bars remain visible at full health, show current/max HP, shrink as damage is dealt and change color with remaining health. Melee reach and encircling positions are expanded to fit the larger body.

Baseline soldiers have 55 HP and hit for 12 damage every 0.65 seconds. Apex creatures have 1,920 HP and strike for 19 damage after a 0.7-second windup and 0.45-second recovery. Three successful strikes defeat one full-health soldier. Creature health scales at spawn with current soldier damage (1,920 × damage/12). Damage uses normal cooldowns and focused targeting, with no forced casualty quota. A fresh squad of ten lost three soldiers in every tested species/level/rate combination. Smaller or wounded squads can lose; prior creature damage, terrain, retreat and later upgrades change the outcome. Player testing is still needed.

An apex creature defeat grants 90 food, 60 leaves, 25 nectar and 100 XP once. Any food overflow is retained on the encounter and paid into available storage. Creature health, discovery, defeat/reward flags, deferred food, squad IDs and countdown survive saves. Version 1 boss-only saves retain boss health, discoveries, countdown, squad and inventory while receiving 12 common creatures once. Current saves retain their tier, weak-spawn slot and deaths, preventing duplicate creatures or accidental resurrection. Legacy pre-wildlife saves retain their colony stock, rooms and resource depots.

Butterflies, fireflies, pollen, swaying grass and moving shadows add bounded ambient animation. Runtime remains procedural and offline-capable in the standalone build.

The supplied 38.9-second gameplay clip was sampled at five-second intervals. Its convoy, explicit Attack/Retreat choices, large creature silhouette, visible enemy health and 10-to-7 army count informed the tactical presentation. UNDERROOT retains its own procedural art and interface. Added creature lunges, bite flashes, incoming-hit rings, bounded floating damage, fading fallen ants and an active/casualty/victory tally. No clip assets were extracted into the game.

## Weaker wildlife, faster explorer and Frontier Atlas

The restored common creatures retain 48/105/125/150 HP by species and inflict only 5/9/15/12 damage. They give 20 food and 20 XP once, with food overflow retained. Each common species was defeated by one healthy soldier in an actual movement/cooldown simulation. They keep their smaller silhouettes and a compact health bar when damaged.

The explorer moves at exactly 2× the prior speed for walking, sprinting, joystick input and underground movement. The worker's stored base speed is restored after every update, so normal workers do not inherit the boost. Recruited soldiers keep the previous nearby pace; beyond 130 units they use a catch-up burst until within 80 units. That burst can outrun the explorer's current walk or sprint speed. They regroup by walking, without teleporting. Home patrol speed remains unchanged.

The Frontier Atlas and minimap share nine distinct resource/species icons, unique colony/explorer/landmark symbols, biome names, compass, coordinate grid, priority routes and a matching legend. All living creature locations are shown regardless of discovery; dead creatures disappear. Previously discovered resource depots retain their unique icons, preserving resource exploration. Map aspect ratio matches pointer coordinates, avoiding letterboxed hit mapping. Large desktop layouts retain a clickable minimap during exploration. Browser/mobile layout QA is still pending.

## Progress reset fix

The former reset used native browser confirmation, removed only the main cache key, and reloaded immediately. Native confirmation can be blocked in embedded games; backup/tutorial records remained, Bridge did not overwrite remote keys omitted from its cache, and the original beforeunload listener could write progress back while restarting.

The ↺ button now opens an in-game confirmation with Cancel and Reset choices. Opening it pauses the game; cancelling restores the prior pause state. Confirmation clears all game progress keys, the migration backup, scout state and tutorials, while preserving unrelated browser storage. Empty values are explicitly written to remote storage, including Bridge keys, before reloading. The existing persistence queue ensures an older in-flight save finishes before the final cleared state is saved. Autosaves, background saves and unload saves are blocked for the old instance after confirmation. Normal unload now uses the latest complete serializer as well.

Reset cannot start during an active ad/reward request. Save failure restores the local/cache snapshot, keeps the current colony open and permits retry or cancellation. Session-only games can reset without unavailable browser storage. The original uploaded HTML remains unchanged in original/phase3.html. No real user save was loaded or reset during these fixture tests.

## Executed verification

**162 checks passed:** 16 core, 34 platform/reward, 20 extended, 43 wildlife, 26 Frontier update and 23 reset checks. The included JSON results enumerate them.

- JavaScript syntax checks for every built inline script.
- Baseline game and upgraded game execute in Node VM with a simulated DOM and native Canvas.
- Replaced 100 depots one at a time; repeated stale callbacks; checked counts, type, quantity and IDs.
- Personal harvesting and delivery, bounded overflow, separate seed stock, actual worker priority harvest/return, save roundtrip, legacy migration/backup, queen upgrades, hatching and chamber construction.
- Routes to all 15 initial depots; desktop key input, joystick input, sprint, surface/underground transition and solid-earth geometry.
- Soldier patrol spacing, enemy wind-up/damage/defeat, obstacle attack occlusion, native Canvas rendering of all creature/biome paths and underground rendering.
- Terrain cache remains at or below 36 chunks after traversing many views.
- SDK mocks verify initialization/storage ordering, readiness, pause/resume, mute, ad cancellation/reward signaling, duplicate events, rapid taps, save errors, verified-journal recovery and no resource-depot mutation from rewards.
- Wildlife checks cover hidden attacks and exposed danger markers, sight blocking, camera/underground discovery exclusion, 0/7/10/15 recruitment, follow/return movement, reserve patrols, retreat, timer boundaries, host/user/ad/background pause, save migration, reward idempotency, reserved food, focused attack orders, persistent retreat, battle casualty counts and bounded effects. Sixteen full movement/separation combat simulations (four species × levels 1/4 × 30/60 Hz) each ended with seven of ten soldiers alive.
- Frontier update checks cover 12 restored weak creatures, one-soldier duels, distinct smaller bonuses, doubled body raster bounds, current/max health bar depletion, nine distinct icon raster signatures, visible unknown danger locations, known supplies, dead-marker removal, map legend, clickable minimap, preserved underground atlas context, 2× walking/sprinting/joystick/nest motion, unchanged worker base speed, sprinting escort catch-up, unchanged home patrol speed and v1/v2 save migration.
- Reset checks cover custom confirmation without native dialogs, cancel/pause preservation, active-ad blocking, complete normal-unload saves, double confirmation, local and session-only resets, unrelated-key preservation, autosave/unload protection, fresh colony after restart, save failure/rollback/retry, queued YouTube writes and explicit Bridge cloud-key clearing. Cloud cases use SDK mocks.
- Local target size and cross-SDK isolation checks. Release ZIP roots/integrity/sizes are checked by `package.py`.

## Measured simulation timing

Node VM, simulated DOM, no browser rendering in the timed section; 300 simulation ticks per population. These are local simulation costs, **not FPS or device benchmarks**. No peak browser heap, real loading time or mobile frame-rate measurement is claimed.

| Ants | Milliseconds per simulation tick |
| --- | ---: |
| 10 | 0.993 |
| 25 | 1.547 |
| 50 | 4.259 |
| 100 | 5.063 |

## Browser and platform status

A real browser was not available. Playwright was installed but Chromium was missing; its standard download repeatedly returned an unusable archive. No browser play-through, CSS layout validation, mobile hardware test or live ad was executed. Native Canvas images were visually inspected for surface and creature scenes; these images do not validate HTML HUD/touch layout.

SDK calls were checked against the current official references linked in `PUBLISHING_GUIDE.md`, then tested with mocks. No developer login, submission, acceptance, certification or revenue was verified. Playgama's localization and natural-transition interstitial requirements still need implementation/review before submission. Only English UI is shipped. YouTube host-device compatibility and Test Suite execution are outstanding.

## Remaining acceptance checklist

1. Play in actual desktop browsers and on Android/iOS, portrait and landscape. Check six-resource HUD, modal focus, joystick/Sprint/Access clearance, pinch zoom and touch target sizing.
2. Exercise real Playgama and YouTube previews: cloud conflict/failure behavior, lifecycle event order, readiness timing, monetization settings and real ad completion/no fill.
3. Complete Playgama localization and a compliant natural-break interstitial policy; recheck the current Required Steps before submitting.
4. Profile browser/mobile render time, peak memory and startup transfer/readiness. Balance distant journeys and combat with human play-testing.
5. If a platform cannot persist a verified reward journal before eviction, that unsaved confirmation is not recoverable; the UI requests retry and never invents a reward.

No missing local assets were found. Gameplay, art and sound remain procedural and dependency-free at runtime; platform editions require their official remote SDK.

# UNDERROOT — The Wild Frontier

A playable upgrade of your Phase 3 ant colony game. Keep the original as a backup.

## Play on your computer

1. Extract `UNDERROOT_Wild_Frontier_Standalone.zip`.
2. Open `index.html` in Chrome, Edge, Firefox or Safari.
3. Click **ENTER THE COLONY**. Your explorer has a gold ring.
4. Approach a supply pile. Choose **GATHER MYSELF**, then **HOME** to deliver, or **SEND WORKERS**.
5. Hatch workers and soldiers, upgrade your queen, and excavate new rooms. Keep food coming in.
6. Tap **RECRUIT · UP TO 10** (or press **R**) to take up to ten existing soldiers with you. With seven available, all seven follow. This does not hatch new soldiers. You may need to build/upgrade barracks to train ten.
7. Extra soldiers patrol slowly around the anthill. **DISMISS** sends your escort home on foot; guards recover health near home. Use Army → Recruit escort if the gathering panel is covering the squad panel.
8. Explore beyond the meadow to find landmarks and dangerous creatures. Creature locations are marked on the map immediately: red triangles are powerful apex encounters; amber circles are weaker creatures. Their bodies appear when your explorer approaches with a clear line of sight. The map starts with one apex creature plus 12 weaker spiders, beetles, mantises and rival ants; another apex arrives every ten minutes of active gameplay. Paused, background and ad time do not count.
9. Bring a healthy full squad close to a discovered creature for automatic defense, or tap **ATTACK** to send a focused assault. Soldiers spread around the creature while biting. **RETREAT** cancels the assault and leads the explorer and surviving escort back to the anthill. The battle panel tracks soldiers remaining and fallen, with visible strike flashes, damage numbers and fading fallen ants. Fresh squads in controlled tests lost three soldiers and returned with seven; injuries, spacing, obstacles, prior damage and upgrades can change the result.
10. An apex defeat earns **90 food, 60 leaves, 25 nectar and 100 XP** without an ad. A weaker creature gives **20 food and 20 XP**. Food that does not fit in storage is reserved and delivered when room opens.

If opening the file directly prevents saving, open a terminal in the extracted folder and run `python3 -m http.server 8000` (Windows: `py -m http.server 8000`). Visit http://localhost:8000. Keep the same browser and address for your saves.

## Controls

- R / RECRUIT: recruit or refill an escort, maximum 10. DISMISS: return to patrol.
- WASD / arrows: walk at twice the previous speed. Shift / hold Sprint: sprint. Recruited soldiers keep their normal nearby pace and briefly speed up to catch up when distant; home patrols stay slow.
- Click or tap: walk to a destination. Drag: pan. Wheel / pinch: zoom.
- E / Access button: gather, enter the nest, or inspect a nearby room.
- HOME button: bring a carried supply home. M / MAP: open the Frontier Atlas. On larger desktop screens, tap the minimap to enlarge it.
- Map legend: each resource and creature type has a unique icon. Red triangles mark apex danger; amber circles mark common creatures. Tap a marker location to walk there.
- Surface / Underground buttons: switch scenes. Use pale underground tunnels.
- Mobile: joystick, Sprint, Access and on-screen management buttons.
- ↺ / Reset progress: open the in-game confirmation. Choose KEEP MY COLONY to cancel or RESET PROGRESS to start fresh. The game waits for its save service before restarting; failed saves leave your current colony open for retry.
- Escape: leave explorer / map in standalone and YouTube. Playgama retains on-screen close controls and uses F8 instead.

## What changed

- 4,700 × 4,700 surface instead of 2,100 × 2,100: 5.01 times the area.
- Three large depots for each of food, leaves, seeds, nectar and soil. Each begins at 1,000–2,300 units.
- One exhausted depot produces one replacement of the same type, with a new ID.
- Green Meadow, Forest Floor, Sunstone Ridge and Shadow Wilds; four discoverable landmarks.
- Local ant separation, distinct soldier patrols, worker reservations and obstacle routes.
- Twelve weaker roaming creatures remain alongside the large encounters.
- Powerful creatures render at twice their previous size with a wide current/max HP bar above the body.
- Four named dangerous creature types: Silkfang Matriarch, Ironback Crusher, Thornblade Hunter and Ember War Captain. Attack wind-ups, warning rings, bounded pursuit and persistent discovery.
- Butterflies, fireflies, drifting pollen, wind-bent grass and moving cloud shadows.
- Safe nest area, resource labels, shrinking piles, explored map markers and supply trails.
- Separate seeds inventory. Convert **10 seeds → 10 food** in the Colony tab when storage has room.
- Optional Bonus Center. Offline ads are disabled; ordinary play always works.

## Saves

Old colony progress is retained on the same browser origin. Old surface coordinates move into the larger world; old small resource nodes are replaced. The first migrated save is retained as `underroot_colony_v1_before_frontier`. New saves include deposits, discovery, priorities, creature health, spawn countdown, squad membership, bonus claims, cargo, settings and reward transactions. Existing Frontier saves retain colony and encounter progress. Older boss-only saves receive the restored small creatures once; their casualties stay saved. Remote targets use their own platform storage. Saves do not transfer automatically between platforms or addresses.

## Source and rebuilding

`original/phase3.html` retains the original upload unchanged. `src/base.html` includes a small gathering arrival-tolerance fix; `frontier.js`, `navigation.js`, `wildlife.js`, `map.js`, `reset.js`, `rewards.js`, CSS and platform adapters maintain the upgrade. Run `python3 build.py` to regenerate `index.html` and the three `dist/` folders. No npm installation or build dependencies are needed for the game.

Automated checks use Node, the test DOM harness, and `@napi-rs/canvas`. They are code-level tests, not browser play-testing. Install that package for local tests or use the configured Codex runtime. From the parent of this repository run `node underroot/tests/core.cjs` and `node underroot/tests/platforms.cjs`; if the folder has another name, update the test paths or use the test runner described in `tests/README.md`.

## Status

This is a review build. Browser/mobile play-testing and real platform QA remain required. No account registration, submission, live hosting or advertising revenue has been performed. See the publishing guide and test report.

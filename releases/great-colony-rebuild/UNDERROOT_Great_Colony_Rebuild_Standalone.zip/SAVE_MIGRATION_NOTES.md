# Saves

Existing schema-4 saves remain readable by the supplied loader. New progression is stored in an additive `journey` object on the same save. Existing saves without it start the new quest arc at its first step; colony resources, deposits and other legacy fields remain managed by the original serializer. Unknown quest schema is ignored. Reset continues to remove this game's progress namespace.

Standalone uses the existing local-storage keys, so retain the browser origin to continue. Playgama stores the entire cache as `underroot_bundle_v1` via official Bridge storage. Standalone and cloud saves are not automatically transferred between different origins/platforms. Cloud migration from a separately published live build is unverified and must be tested with its actual save format before deployment.

Original supplied ZIP SHA-256: 10df9ada455b5214159fb2aa2912b51c6ea249ed19e43921f1a5561e01937adf. Restore original/source.zip to revert application files. Back up browser/platform saves separately before deploying; a source backup does not contain a player's browser data.

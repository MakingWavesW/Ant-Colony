# UNDERROOT — Great Colony Rebuild, playable increment 1

Unzip the standalone package. From its folder run `python3 -m http.server 8000`, then open the local server in a modern browser. Click ENTER THE COLONY. SHOW TRAIL walks your ant toward the current resource; GATHER collects it and HOME returns it. Use Colony and Build to grow, Army to recruit, and Journal to review your adventure and adjust music volume. Movement uses WASD, clicks or the touch joystick.

For Playgama, upload the separate Playgama ZIP to a Sandbox draft. Its index.html is at the archive root. Validate real cloud saves, audio lifecycle and rewarded ads on the platform before replacing the live game. This delivery has not been published or submitted. The supplied source is preserved in original/source.zip in the development workspace.

The supplied tracks are included; commercial distribution rights have not been independently verified. The supplied illustration was visible as a chat image but had no downloadable file pointer; it is not included. No claim is made that the premium loading-art milestone is complete.

This is a tested playable increment, not completion of every master-prompt milestone. See PERFORMANCE_AND_TEST_REPORT.md for remaining release gates. No YouTube export is supplied. InfinityFree-specific hosting limits were not verified.

# Technology decision — 2026-10-31

The supplied 287 KB HTML already contains Canvas rendering, layered procedural art, gait animation, spatial worker queries, soldier formations, creature combat, collision, deposits and schema-4 saves. Preserve that implementation and add small external progression/audio/UI modules.

| Option | Benefit | Migration risk | Decision |
|---|---|---|---|
| Existing Canvas + JavaScript | Keeps tested gameplay, no renderer dependency, fast startup | Existing layered globals require careful wrappers | Selected |
| PixiJS / Phaser | Sprite batching, scene/input infrastructure | Rewrite draw/input contracts and retest every system | Defer until profiling warrants migration |
| Selective Three.js/WebGL | Lighting and depth | Assets, camera, hit testing, context recovery and mobile GPU cost | Not justified for this increment |

Official Playgama Bridge 2.4.0 is the only added runtime library in the platform export. It is bundled locally and unmodified. Standalone has no platform SDK. No framework demonstration or wholesale rewrite was undertaken.

# Build underroot-rebuild-20261031

Added a twelve-step persisted adventure director with action-based triggers and one visible objective, progress indicator, journal, and modest leaf rewards. Added a near-home first leaf, world-space route guide and SHOW TRAIL movement using existing navigation. Existing tutorial and mission logic remain intact.

Added separate menu/exploration/battle music, user-gesture unlock, volume control, approximate one-second crossfades, combat hysteresis, and platform/mute/background gating. Added responsive quest UI, reduced-motion styles, and mobile squad-panel suppression except in Army.

Added separate Playgama export with locally bundled official Bridge 2.4.0, storage facade integration, pause/audio signals, startup connection fallback, and rewarded-event adapter. Standalone keeps ads unavailable.

Preserved source simulation: surface/nest, gathering and deposits, priorities, collision, worker AI, soldier recruitment/formation/patrol, articulated enemies, combat, discoveries/map, chambers/queen, reset flow, save serialization, and existing reward transaction ledger. Preservation is not a claim that every feature has been exhaustively regression-tested.
